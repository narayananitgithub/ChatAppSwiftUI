//
//  URLType.swift
//  ChatAppSwiftUI
//
//  Created by Narayanasamy on 28/09/24.
//

import Foundation


enum URLType {
    case messages
}

