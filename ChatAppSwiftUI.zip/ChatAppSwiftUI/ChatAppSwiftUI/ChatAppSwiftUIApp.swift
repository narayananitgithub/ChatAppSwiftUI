//
//  ChatAppSwiftUIApp.swift
//  ChatAppSwiftUI
//
//  Created by Narayanasamy on 28/09/24.
//

import SwiftUI

@main
struct ChatAppSwiftUIApp: App {
    @StateObject private var chatViewModel = DependencyInjection.shared.userViewModel()
    // Correct method call
    init() {
            // Ensure the DatabaseManager is initialized
            let _ = DatabaseManager.shared
        }
        

    var body: some Scene {
        WindowGroup {
            ChatView()
                .environmentObject(chatViewModel) // Inject the environment object
        }
    }
}
