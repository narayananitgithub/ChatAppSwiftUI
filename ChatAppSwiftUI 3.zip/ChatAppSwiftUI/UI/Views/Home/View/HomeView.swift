//
//  HomeView.swift
//  ChatAppSwiftUI
//
//  Created by Narayanasamy on 28/09/24.
//

import SwiftUI

import SwiftUI

struct HomeView: View {
    @StateObject private var chatViewModel = ChatViewModel()
    
    var body: some View {
        ChatView()
    }
}

#Preview {
   HomeView()
}
