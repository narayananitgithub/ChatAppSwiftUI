//
//  ChatViewModel.swift
//  ChatAppSwiftUI
//
//  Created by Narayanasamy on 28/09/24.
//

import Foundation
import Combine


import Combine
import Foundation

class ChatViewModel: ObservableObject {
    @Published var messages: [Message] = []
    @Published var newMessageContent: String = "" // Add this line
    private var cancellables = Set<AnyCancellable>()

    // Function to fetch messages from the database
    func fetchMessages() {
        do {
            // Fetch messages from the database
            self.messages = try DatabaseManager.shared.fetchMessages()
        } catch {
            print("Error fetching messages: \(error)")
        }
    }
    
    // Function to send a message
    func sendMessage(content: String, userId: String) {
        let message = Message(id: UUID().uuidString, content: content, timestamp: Date(), userId: userId)
        do {
            try DatabaseManager.shared.saveMessage(message: message)
            fetchMessages() // Refresh messages after sending
        } catch {
            print("Error sending message: \(error)")
        }
    }
}
