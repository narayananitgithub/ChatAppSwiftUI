//
//  ChatView.swift
//  ChatAppSwiftUI
//
//  Created by Narayanasamy on 28/09/24.
//

import SwiftUI

import SwiftUI

struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    
    var body: some View {
        NavigationView {
            VStack {
                List(viewModel.messages) { message in
                    VStack(alignment: .leading) {
                        Text(message.content)
                            .font(.body)
                        Text(message.timestamp, style: .time)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                
                // Add a TextField for sending messages (for example)
                TextField("Type your message...", text: $viewModel.newMessageContent)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(action: {
                    viewModel.sendMessage(content: viewModel.newMessageContent, userId: "1") // Example user ID
                    viewModel.newMessageContent = "" // Clear input after sending
                }) {
                    Text("Send")
                }
                .padding()
            }
            .navigationTitle("Chat App") // Set the title here
            .onAppear {
                viewModel.fetchMessages() // Load messages when the view appears
            }
        }
    }
}
