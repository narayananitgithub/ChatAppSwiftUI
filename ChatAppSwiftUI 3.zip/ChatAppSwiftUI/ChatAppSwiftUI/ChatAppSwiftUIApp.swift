//
//  ChatAppSwiftUIApp.swift
//  ChatAppSwiftUI
//
//  Created by Narayanasamy on 28/09/24.
//

import SwiftUI

@main
struct ChatAppSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
